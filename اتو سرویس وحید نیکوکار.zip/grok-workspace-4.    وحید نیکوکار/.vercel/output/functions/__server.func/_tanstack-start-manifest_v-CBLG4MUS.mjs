//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CBLG4MUS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Kwkr97QA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Kwkr97QA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D3aLjFQk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
