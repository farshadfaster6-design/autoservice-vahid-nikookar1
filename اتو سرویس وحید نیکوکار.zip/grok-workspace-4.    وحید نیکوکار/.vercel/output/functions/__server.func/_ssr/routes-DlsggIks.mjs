import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Phone, c as MapPin, d as Copy, f as Check, l as Gauge, n as Wrench, o as MessageCircle, r as Warehouse, s as Menu, t as X, u as Disc3 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DlsggIks.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHONE = "09123434464";
var PHONE_FA = "۰۹۱۲۳۴۳۴۴۶۴";
var TEL = `tel:${PHONE}`;
var WA = "https://wa.me/989123434464";
var ADDRESS = "تهران، خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱";
var MAPS = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("تهران خیابان آزادی ابتدای خیابان بهبودی پلاک 38")}`;
var NESHAN = `https://neshan.org/maps/search/${encodeURIComponent("تهران خیابان آزادی خیابان بهبودی")}`;
var NAV = [
	{
		href: "#services",
		label: "خدمات"
	},
	{
		href: "#parts",
		label: "انبار قطعه"
	},
	{
		href: "#method",
		label: "روند کار"
	},
	{
		href: "#visit",
		label: "آدرس و نوبت"
	}
];
var SERVICES = [
	{
		title: "تنظیم زاویه چرخ",
		image: "/media/sensor.jpg",
		alt: "حسگر دستگاه تنظیم زاویه چرخ کنار لاستیک",
		text: "کمبر، کستر و توی چرخ روی دستگاه خوانده و تنظیم می‌شود. خودرو مستقیم می‌رود، فرمان به مرکز برمی‌گردد و لاستیک یکنواخت ساییده می‌شود.",
		icon: Gauge
	},
	{
		title: "بالانس و رفع لرزش",
		image: "/media/balance.jpg",
		alt: "چرخ روی دستگاه بالانس",
		text: "لرزش فرمان، پدال یا بدنه در یک بازه‌ی سرعت، اغلب از نابالانسی چرخ است. بالانس دقیق همان لرزش را می‌گیرد؛ اگر علت جای دیگری باشد، همان‌جا مشخص می‌شود.",
		icon: Disc3
	},
	{
		title: "جلوبندی",
		image: "/media/front.jpg",
		alt: "مجموعه‌ی جلوبندی خودرو شامل طبق، فنر و سیبک",
		text: "سیبک، طبق، کمک‌فنر، بوش، میل موج‌گیر و اتصالات جلو بررسی می‌شود. لقی، کوبش یا کشیدن فرمان را با تعویض یا تعمیر همان قطعه برطرف می‌کنیم.",
		icon: Wrench
	},
	{
		title: "زیربندی",
		image: "/media/under.jpg",
		alt: "نمای زیربندی خودرو از داخل چال سرویس",
		text: "اکسل، فنرها، بوش‌ها و اتصالات زیر خودرو روی پایداری و راحتی سواری اثر دارند. بازدید از چال انجام می‌شود تا ایراد، حدس نباشد.",
		icon: Warehouse
	}
];
var STEPS = [
	{
		n: "۰۱",
		title: "تشخیص روی خودرو",
		text: "لرزش، کشیدن فرمان یا صدای جلوبندی را روی خود خودرو جدا می‌کنیم؛ نه با حدس از پشت تلفن."
	},
	{
		n: "۰۲",
		title: "قطعه از انبار مجموعه",
		text: "برای جلوبندی و زیربندی لازم نیست خودتان بازار بروید. قطعه از انبار همین مجموعه تأمین می‌شود."
	},
	{
		n: "۰۳",
		title: "تعمیر و تنظیم",
		text: "بعد از بستن قطعه، زاویه چرخ دوباره تنظیم می‌شود تا کار نیمه‌کاره تحویل داده نشود."
	},
	{
		n: "۰۴",
		title: "کنترل لرزش",
		text: "بالانس و یک مرور نهایی تا فرمان و بدنه در سرعت، آرام باشد."
	}
];
var ANGLES = [
	{
		name: "کمبر",
		text: "شیب چرخ نسبت به خط عمود. به‌هم‌ریختنش لاستیک را از داخل یا بیرون می‌ساید."
	},
	{
		name: "کستر",
		text: "زاویه‌ی محور فرمان. روی برگشت فرمان به مرکز و پایداری در جاده اثر دارد."
	},
	{
		name: "تو",
		text: "هم‌گرایی یا واگرایی چرخ‌ها. تنظیمش جلوی کشیدن خودرو به یک سمت را می‌گیرد."
	}
];
var FAQS = [
	{
		q: "خودم باید قطعه بخرم؟",
		a: "نه. اگر ایراد از جلوبندی یا زیربندی باشد، قطعه از انبار مجموعه تأمین می‌شود تا کار معطل خرید شما نشود. برای مدل کم‌یاب، قبل از آوردن خودرو یک تماس بگیرید."
	},
	{
		q: "چه وقت تنظیم زاویه چرخ لازم است؟",
		a: "بعد از ضربه به چرخ یا جدول، بعد از تعویض قطعات جلوبندی، وقتی خودرو به یک سمت می‌کشد، فرمان کج برمی‌گردد، یا ساییدگی لاستیک یک‌طرفه شده است."
	},
	{
		q: "هر لرزشی یعنی چرخ بالانس نیست؟",
		a: "نه همیشه. لرزش می‌تواند از بالانس، از زاویه‌ی چرخ، یا از لقی جلوبندی و زیربندی باشد. اول علت جدا می‌شود، بعد همان قسمت درست می‌شود."
	},
	{
		q: "آدرس دقیق مجموعه کجاست؟",
		a: "تهران، خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱. نام مجموعه روی سردر: اتوسرویس وحید نیکوکار."
	}
];
function waLink(name, car, note) {
	const lines = [
		"سلام. برای نوبت اتوسرویس وحید نیکوکار پیام می‌دهم.",
		name.trim() ? `نام: ${name.trim()}` : "",
		car.trim() ? `خودرو: ${car.trim()}` : "",
		note.trim() ? `شرح: ${note.trim()}` : ""
	].filter(Boolean);
	return `${WA}?text=${encodeURIComponent(lines.join("\n"))}`;
}
function Site() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [faq, setFaq] = (0, import_react.useState)(0);
	const [name, setName] = (0, import_react.useState)("");
	const [car, setCar] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	function closeNav() {
		setOpen(false);
	}
	async function copyAddress() {
		try {
			await navigator.clipboard.writeText(`${ADDRESS}\nاتوسرویس وحید نیکوکار\n${PHONE_FA}`);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 2e3);
		} catch {
			setCopied(false);
		}
	}
	function sendVisit(event) {
		event.preventDefault();
		window.open(waLink(name, car, note), "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:right-3 focus:z-50 focus:bg-brass focus:px-4 focus:py-2 focus:text-ink",
				children: "پرش به محتوا"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-ink/10 bg-paper/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-extrabold leading-5",
									children: "اتوسرویس وحید نیکوکار"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs text-steel",
									children: "جلوبندی و زیربندی خودرو"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "ms-auto hidden items-center gap-6 lg:flex",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: item.href,
								className: "text-sm font-medium text-ink/80 hover:text-ink",
								children: item.label
							}, item.href))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: TEL,
							className: "ms-auto hidden h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm font-bold text-paper lg:ms-4 lg:inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4",
								"aria-hidden": "true"
							}), PHONE_FA]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ms-auto inline-flex size-11 items-center justify-center rounded-full border border-ink/15 lg:hidden",
							"aria-expanded": open,
							"aria-controls": "mobile-nav",
							onClick: () => setOpen((v) => !v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: open ? "بستن منو" : "باز کردن منو"
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })]
						})
					]
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					id: "mobile-nav",
					className: "border-t border-ink/10 bg-paper px-4 py-3 lg:hidden",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						onClick: closeNav,
						className: "flex h-12 items-center border-b border-ink/10 text-base font-medium last:border-0",
						children: item.label
					}, item.href))
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "content",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "top",
						className: "relative isolate overflow-hidden bg-ink text-paper",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/bay.jpg",
								alt: "سالن تنظیم زاویه چرخ با خودرو روی دستگاه",
								className: "absolute inset-0 h-full w-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/78 md:bg-gradient-to-l md:from-ink md:via-ink/88 md:to-ink/25" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mx-auto grid min-h-[calc(100svh-4rem)] max-w-6xl items-end gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] lg:items-center lg:py-20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-w-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-4 inline-flex items-center gap-2 text-sm font-medium text-brass",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "h-px w-8 bg-brass",
												"aria-hidden": "true"
											}), "تهران، خیابان آزادی"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-4xl font-extrabold leading-tight sm:text-5xl",
											children: "جلوبندی و زیربندی، با تنظیم دقیق زاویه چرخ"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-5 max-w-lg text-base leading-relaxed text-paper/85 sm:text-lg",
											children: "فرمان می‌کشد، لاستیک یک‌طرفه ساییده می‌شود، یا بدنه در سرعت می‌لرزد؟ در اتوسرویس وحید نیکوکار زاویه چرخ با دستگاه‌های به‌روز تنظیم می‌شود، چرخ بالانس می‌شود و لرزش گرفته می‌شود."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-8 flex flex-col gap-3 sm:flex-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: TEL,
												className: "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-brass px-6 text-sm font-extrabold text-ink",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
													className: "size-4",
													"aria-hidden": "true"
												}), "تماس برای نوبت"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "#visit",
												className: "inline-flex h-12 items-center justify-center rounded-full border border-paper/30 px-6 text-sm font-bold text-paper",
												children: "آدرس و پیام"
											})]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid grid-cols-2 gap-3 lg:max-w-sm lg:justify-self-end",
									children: [
										["دستگاه روز", "تنظیم زاویه چرخ"],
										["بالانس", "رفع لرزش فرمان و بدنه"],
										["انبار قطعه", "بدون خرید جداگانه‌ی شما"],
										["آدرس", "پلاک ۳۸ تا ۴۱ بهبودی"]
									].map(([title, line]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "border border-paper/20 bg-ink/55 p-4 backdrop-blur-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-extrabold text-brass",
											children: title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm leading-6 text-paper/90",
											children: line
										})]
									}, title))
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "services",
						className: "scroll-mt-20 mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-brass-deep",
									children: "خدمات مجموعه"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-3xl font-extrabold leading-tight sm:text-4xl",
									children: "از زاویه چرخ تا زیربندی، یک‌جا"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base leading-relaxed text-steel",
									children: "کار این مجموعه جلوبندی و زیربندی است؛ با دستگاه تنظیم زاویه، بالانس چرخ و رفع لرزش. تشخیص و اجرا هر دو داخل مجموعه انجام می‌شود."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-5 sm:grid-cols-2",
							children: SERVICES.map((item) => {
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "overflow-hidden border border-ink/10 bg-paper",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative aspect-[3/2]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: item.image,
											alt: item.alt,
											className: "h-full w-full object-cover"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-5 sm:p-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-brass-deep",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "size-5",
												"aria-hidden": "true"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl font-extrabold text-ink",
												children: item.title
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm leading-7 text-steel",
											children: item.text
										})]
									})]
								}, item.title);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "angles",
						className: "border-y border-ink/10 bg-ink text-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-8 px-4 py-14 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-brass",
									children: "سه زاویه‌ای که دستگاه می‌خواند"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-3xl font-extrabold",
									children: "تنظیم، با عدد؛ نه با چشم"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm leading-7 text-paper/75",
									children: "دستگاه به‌روز، زاویه چرخ را قبل و بعد از کار نشان می‌دهد. به همین خاطر سایش لاستیک و کشیدن فرمان، شانسی درست نمی‌شود."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "grid gap-4 sm:grid-cols-3",
								children: ANGLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border border-paper/15 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-extrabold text-brass",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-7 text-paper/80",
										children: item.text
									})]
								}, item.name))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "parts",
						className: "scroll-mt-20 mx-auto grid max-w-6xl items-center gap-8 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden border border-ink/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/stock.jpg",
								alt: "قفسه‌های انبار قطعات جلوبندی و زیربندی",
								className: "aspect-[3/2] h-full w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold text-brass-deep",
								children: "مزیت مجموعه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-3xl font-extrabold leading-tight sm:text-4xl",
								children: "قطعه را خودتان تهیه نکنید"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base leading-8 text-steel",
								children: "اگر ایراد از جلوبندی یا زیربندی خودرو باشد، لازم نیست جداگانه دنبال قطعه‌ی یدکی بگردید. انبار مجموعه قطعات خودروهای مختلف را موجود دارد تا تعمیر هم سریع‌تر پیش برود، هم قطعه با همان کاری که انجام می‌شود جور باشد."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 space-y-3 text-sm leading-7",
								children: [
									"معطل خرید قطعه از بازار نمی‌مانید.",
									"قطعه کنار همان کاری انتخاب می‌شود که روی خودرو لازم است.",
									"برای خودروی خاص، موجودی را قبل از مراجعه تلفنی چک کنید."
								].map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "mt-1 size-4 shrink-0 text-brass-deep",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: line })]
								}, line))
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "method",
						className: "scroll-mt-20 border-t border-ink/10 bg-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-extrabold sm:text-4xl",
								children: "از ورود خودرو تا تحویل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
								children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border border-ink/10 p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-extrabold text-brass-deep",
											children: step.n
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 text-lg font-extrabold",
											children: step.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-7 text-steel",
											children: step.text
										})
									]
								}, step.n))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "visit",
						className: "scroll-mt-20 bg-ink text-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-6 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border border-paper/15 p-6 sm:p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-brass",
										children: "مراجعه"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 text-3xl font-extrabold",
										children: "اتوسرویس وحید نیکوکار"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-4 flex gap-3 text-base leading-8 text-paper/85",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
											className: "mt-1 size-5 shrink-0 text-brass",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ADDRESS })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: TEL,
										className: "mt-4 flex items-center gap-3 text-2xl font-extrabold text-brass",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
											className: "size-6",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											dir: "ltr",
											children: PHONE_FA
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-paper/70",
										children: "نوبت با تماس یا پیام هماهنگ می‌شود."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 flex flex-col gap-3 sm:flex-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: MAPS,
												target: "_blank",
												rel: "noreferrer",
												className: "inline-flex h-12 items-center justify-center rounded-full bg-paper px-5 text-sm font-extrabold text-ink",
												children: "مسیریابی"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: NESHAN,
												target: "_blank",
												rel: "noreferrer",
												className: "inline-flex h-12 items-center justify-center rounded-full border border-paper/25 px-5 text-sm font-bold",
												children: "نقشه نشان"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: copyAddress,
												className: "inline-flex h-12 items-center justify-center gap-2 rounded-full border border-paper/25 px-5 text-sm font-bold",
												children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "کپی شد" : "کپی آدرس"]
											})
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: sendVisit,
								className: "border border-paper/15 bg-paper p-6 text-ink sm:p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-extrabold",
										children: "درخواست نوبت"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-7 text-steel",
										children: "مشخصات را بنویسید. پیام در واتساپ باز می‌شود تا همان را برای مجموعه بفرستید."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mt-5 block text-sm font-bold",
										htmlFor: "guest-name",
										children: "نام"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "guest-name",
										value: name,
										onChange: (event) => setName(event.target.value),
										autoComplete: "name",
										suppressHydrationWarning: true,
										className: "mt-2 h-12 w-full border border-ink/15 bg-paper px-3 text-base outline-none focus-visible:border-brass-deep"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mt-4 block text-sm font-bold",
										htmlFor: "guest-car",
										children: "مدل خودرو"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "guest-car",
										value: car,
										onChange: (event) => setCar(event.target.value),
										placeholder: "مثلاً پژو ۴۰۵",
										suppressHydrationWarning: true,
										className: "mt-2 h-12 w-full border border-ink/15 bg-paper px-3 text-base outline-none placeholder:text-steel/70 focus-visible:border-brass-deep"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mt-4 block text-sm font-bold",
										htmlFor: "guest-note",
										children: "مشکل خودرو"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "guest-note",
										value: note,
										onChange: (event) => setNote(event.target.value),
										rows: 4,
										placeholder: "لرزش فرمان، کشیدن به یک سمت، صدای جلوبندی…",
										suppressHydrationWarning: true,
										className: "mt-2 w-full border border-ink/15 bg-paper px-3 py-3 text-base leading-7 outline-none placeholder:text-steel/70 focus-visible:border-brass-deep"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										className: "mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-ink text-sm font-extrabold text-paper",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
											className: "size-4",
											"aria-hidden": "true"
										}), "ارسال در واتساپ"]
									})
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "faq",
						className: "mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-extrabold",
							children: "پرسش‌های رایج"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 border-t border-ink/10",
							children: FAQS.map((item, index) => {
								const isOpen = faq === index;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-b border-ink/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "flex w-full items-center justify-between gap-4 py-4 text-start text-base font-extrabold",
										"aria-expanded": isOpen,
										onClick: () => setFaq(isOpen ? -1 : index),
										children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-brass-deep",
											"aria-hidden": "true",
											children: isOpen ? "−" : "+"
										})]
									}), isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "pb-4 text-sm leading-8 text-steel",
										children: item.a
									}) : null]
								}, item.q);
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-ink/10 pb-24 md:pb-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-steel sm:px-6 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold text-ink",
						children: "اتوسرویس وحید نیکوکار"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-md leading-7",
						children: ADDRESS
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: TEL,
						className: "font-bold text-ink",
						dir: "ltr",
						children: PHONE_FA
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-x-0 bottom-0 z-40 flex gap-2 border-t border-paper/15 bg-ink p-3 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: TEL,
					className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-paper text-sm font-extrabold text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
						className: "size-4",
						"aria-hidden": "true"
					}), "تماس"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: WA,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-brass text-sm font-extrabold text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
						className: "size-4",
						"aria-hidden": "true"
					}), "واتساپ"]
				})]
			})
		]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 40 40",
		className: "size-10 shrink-0",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "40",
				height: "40",
				fill: "#12161a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "20",
				r: "11",
				fill: "none",
				stroke: "#e2b15c",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "20",
				r: "3",
				fill: "none",
				stroke: "#e2b15c",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 6v6M20 28v6M6 20h6M28 20h6",
				stroke: "#f4f0e6",
				strokeWidth: "1.4"
			})
		]
	});
}
var SplitComponent = Site;
//#endregion
export { SplitComponent as component };
