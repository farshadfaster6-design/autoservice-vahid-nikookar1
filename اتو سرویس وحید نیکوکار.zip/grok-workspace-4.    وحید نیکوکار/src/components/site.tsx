import { useState, type FormEvent } from "react";
import {
  Check,
  Copy,
  Disc3,
  Gauge,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Warehouse,
  Wrench,
  X,
} from "lucide-react";

const PHONE = "09123434464";
const PHONE_FA = "۰۹۱۲۳۴۳۴۴۶۴";
const TEL = `tel:${PHONE}`;
const WA = "https://wa.me/989123434464";
const ADDRESS = "تهران، خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱";
const MAPS = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  "تهران خیابان آزادی ابتدای خیابان بهبودی پلاک 38",
)}`;
const NESHAN = `https://neshan.org/maps/search/${encodeURIComponent(
  "تهران خیابان آزادی خیابان بهبودی",
)}`;

const NAV = [
  { href: "#services", label: "خدمات" },
  { href: "#parts", label: "انبار قطعه" },
  { href: "#method", label: "روند کار" },
  { href: "#visit", label: "آدرس و نوبت" },
];

const SERVICES = [
  {
    title: "تنظیم زاویه چرخ",
    image: "/media/sensor.jpg",
    alt: "حسگر دستگاه تنظیم زاویه چرخ کنار لاستیک",
    text: "کمبر، کستر و توی چرخ روی دستگاه خوانده و تنظیم می‌شود. خودرو مستقیم می‌رود، فرمان به مرکز برمی‌گردد و لاستیک یکنواخت ساییده می‌شود.",
    icon: Gauge,
  },
  {
    title: "بالانس و رفع لرزش",
    image: "/media/balance.jpg",
    alt: "چرخ روی دستگاه بالانس",
    text: "لرزش فرمان، پدال یا بدنه در یک بازه‌ی سرعت، اغلب از نابالانسی چرخ است. بالانس دقیق همان لرزش را می‌گیرد؛ اگر علت جای دیگری باشد، همان‌جا مشخص می‌شود.",
    icon: Disc3,
  },
  {
    title: "جلوبندی",
    image: "/media/front.jpg",
    alt: "مجموعه‌ی جلوبندی خودرو شامل طبق، فنر و سیبک",
    text: "سیبک، طبق، کمک‌فنر، بوش، میل موج‌گیر و اتصالات جلو بررسی می‌شود. لقی، کوبش یا کشیدن فرمان را با تعویض یا تعمیر همان قطعه برطرف می‌کنیم.",
    icon: Wrench,
  },
  {
    title: "زیربندی",
    image: "/media/under.jpg",
    alt: "نمای زیربندی خودرو از داخل چال سرویس",
    text: "اکسل، فنرها، بوش‌ها و اتصالات زیر خودرو روی پایداری و راحتی سواری اثر دارند. بازدید از چال انجام می‌شود تا ایراد، حدس نباشد.",
    icon: Warehouse,
  },
];

const STEPS = [
  {
    n: "۰۱",
    title: "تشخیص روی خودرو",
    text: "لرزش، کشیدن فرمان یا صدای جلوبندی را روی خود خودرو جدا می‌کنیم؛ نه با حدس از پشت تلفن.",
  },
  {
    n: "۰۲",
    title: "قطعه از انبار مجموعه",
    text: "برای جلوبندی و زیربندی لازم نیست خودتان بازار بروید. قطعه از انبار همین مجموعه تأمین می‌شود.",
  },
  {
    n: "۰۳",
    title: "تعمیر و تنظیم",
    text: "بعد از بستن قطعه، زاویه چرخ دوباره تنظیم می‌شود تا کار نیمه‌کاره تحویل داده نشود.",
  },
  {
    n: "۰۴",
    title: "کنترل لرزش",
    text: "بالانس و یک مرور نهایی تا فرمان و بدنه در سرعت، آرام باشد.",
  },
];

const ANGLES = [
  {
    name: "کمبر",
    text: "شیب چرخ نسبت به خط عمود. به‌هم‌ریختنش لاستیک را از داخل یا بیرون می‌ساید.",
  },
  {
    name: "کستر",
    text: "زاویه‌ی محور فرمان. روی برگشت فرمان به مرکز و پایداری در جاده اثر دارد.",
  },
  {
    name: "تو",
    text: "هم‌گرایی یا واگرایی چرخ‌ها. تنظیمش جلوی کشیدن خودرو به یک سمت را می‌گیرد.",
  },
];

const FAQS = [
  {
    q: "خودم باید قطعه بخرم؟",
    a: "نه. اگر ایراد از جلوبندی یا زیربندی باشد، قطعه از انبار مجموعه تأمین می‌شود تا کار معطل خرید شما نشود. برای مدل کم‌یاب، قبل از آوردن خودرو یک تماس بگیرید.",
  },
  {
    q: "چه وقت تنظیم زاویه چرخ لازم است؟",
    a: "بعد از ضربه به چرخ یا جدول، بعد از تعویض قطعات جلوبندی، وقتی خودرو به یک سمت می‌کشد، فرمان کج برمی‌گردد، یا ساییدگی لاستیک یک‌طرفه شده است.",
  },
  {
    q: "هر لرزشی یعنی چرخ بالانس نیست؟",
    a: "نه همیشه. لرزش می‌تواند از بالانس، از زاویه‌ی چرخ، یا از لقی جلوبندی و زیربندی باشد. اول علت جدا می‌شود، بعد همان قسمت درست می‌شود.",
  },
  {
    q: "آدرس دقیق مجموعه کجاست؟",
    a: "تهران، خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱. نام مجموعه روی سردر: اتوسرویس وحید نیکوکار.",
  },
];

function waLink(name: string, car: string, note: string) {
  const lines = [
    "سلام. برای نوبت اتوسرویس وحید نیکوکار پیام می‌دهم.",
    name.trim() ? `نام: ${name.trim()}` : "",
    car.trim() ? `خودرو: ${car.trim()}` : "",
    note.trim() ? `شرح: ${note.trim()}` : "",
  ].filter(Boolean);
  return `${WA}?text=${encodeURIComponent(lines.join("\n"))}`;
}

export function Site() {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [faq, setFaq] = useState(0);
  const [name, setName] = useState("");
  const [car, setCar] = useState("");
  const [note, setNote] = useState("");

  function closeNav() {
    setOpen(false);
  }

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(`${ADDRESS}\nاتوسرویس وحید نیکوکار\n${PHONE_FA}`);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  function sendVisit(event: FormEvent) {
    event.preventDefault();
    window.open(waLink(name, car, note), "_blank", "noopener,noreferrer");
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:right-3 focus:z-50 focus:bg-brass focus:px-4 focus:py-2 focus:text-ink"
      >
        پرش به محتوا
      </a>

      <header className="sticky top-0 z-30 border-b border-ink/10 bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <a href="#top" className="flex min-w-0 items-center gap-3">
            <Mark />
            <span className="min-w-0">
              <span className="block truncate text-sm font-extrabold leading-5">
                اتوسرویس وحید نیکوکار
              </span>
              <span className="block truncate text-xs text-steel">جلوبندی و زیربندی خودرو</span>
            </span>
          </a>
          <nav className="ms-auto hidden items-center gap-6 lg:flex">
            {NAV.map((item) => (
              <a key={item.href} href={item.href} className="text-sm font-medium text-ink/80 hover:text-ink">
                {item.label}
              </a>
            ))}
          </nav>
          <a
            href={TEL}
            className="ms-auto hidden h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm font-bold text-paper lg:ms-4 lg:inline-flex"
          >
            <Phone className="size-4" aria-hidden="true" />
            {PHONE_FA}
          </a>
          <button
            type="button"
            className="ms-auto inline-flex size-11 items-center justify-center rounded-full border border-ink/15 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
          >
            <span className="sr-only">{open ? "بستن منو" : "باز کردن منو"}</span>
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {open ? (
          <nav id="mobile-nav" className="border-t border-ink/10 bg-paper px-4 py-3 lg:hidden">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={closeNav}
                className="flex h-12 items-center border-b border-ink/10 text-base font-medium last:border-0"
              >
                {item.label}
              </a>
            ))}
          </nav>
        ) : null}
      </header>

      <main id="content">
        <section id="top" className="relative isolate overflow-hidden bg-ink text-paper">
          <img
            src="/media/bay.jpg"
            alt="سالن تنظیم زاویه چرخ با خودرو روی دستگاه"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-ink/78 md:bg-gradient-to-l md:from-ink md:via-ink/88 md:to-ink/25" />
          <div className="relative mx-auto grid min-h-[calc(100svh-4rem)] max-w-6xl items-end gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] lg:items-center lg:py-20">
            <div className="max-w-xl">
              <p className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-brass">
                <span className="h-px w-8 bg-brass" aria-hidden="true" />
                تهران، خیابان آزادی
              </p>
              <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl">
                جلوبندی و زیربندی، با تنظیم دقیق زاویه چرخ
              </h1>
              <p className="mt-5 max-w-lg text-base leading-relaxed text-paper/85 sm:text-lg">
                فرمان می‌کشد، لاستیک یک‌طرفه ساییده می‌شود، یا بدنه در سرعت می‌لرزد؟ در اتوسرویس
                وحید نیکوکار زاویه چرخ با دستگاه‌های به‌روز تنظیم می‌شود، چرخ بالانس می‌شود و لرزش
                گرفته می‌شود.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a
                  href={TEL}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-brass px-6 text-sm font-extrabold text-ink"
                >
                  <Phone className="size-4" aria-hidden="true" />
                  تماس برای نوبت
                </a>
                <a
                  href="#visit"
                  className="inline-flex h-12 items-center justify-center rounded-full border border-paper/30 px-6 text-sm font-bold text-paper"
                >
                  آدرس و پیام
                </a>
              </div>
            </div>
            <ul className="grid grid-cols-2 gap-3 lg:max-w-sm lg:justify-self-end">
              {[
                ["دستگاه روز", "تنظیم زاویه چرخ"],
                ["بالانس", "رفع لرزش فرمان و بدنه"],
                ["انبار قطعه", "بدون خرید جداگانه‌ی شما"],
                ["آدرس", "پلاک ۳۸ تا ۴۱ بهبودی"],
              ].map(([title, line]) => (
                <li key={title} className="border border-paper/20 bg-ink/55 p-4 backdrop-blur-sm">
                  <p className="text-sm font-extrabold text-brass">{title}</p>
                  <p className="mt-1 text-sm leading-6 text-paper/90">{line}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="services" className="scroll-mt-20 mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
          <div className="max-w-2xl">
            <p className="text-sm font-bold text-brass-deep">خدمات مجموعه</p>
            <h2 className="mt-2 text-3xl font-extrabold leading-tight sm:text-4xl">
              از زاویه چرخ تا زیربندی، یک‌جا
            </h2>
            <p className="mt-4 text-base leading-relaxed text-steel">
              کار این مجموعه جلوبندی و زیربندی است؛ با دستگاه تنظیم زاویه، بالانس چرخ و رفع لرزش.
              تشخیص و اجرا هر دو داخل مجموعه انجام می‌شود.
            </p>
          </div>
          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {SERVICES.map((item) => {
              const Icon = item.icon;
              return (
                <article key={item.title} className="overflow-hidden border border-ink/10 bg-paper">
                  <div className="relative aspect-[3/2]">
                    <img src={item.image} alt={item.alt} className="h-full w-full object-cover" />
                  </div>
                  <div className="p-5 sm:p-6">
                    <div className="flex items-center gap-2 text-brass-deep">
                      <Icon className="size-5" aria-hidden="true" />
                      <h3 className="text-xl font-extrabold text-ink">{item.title}</h3>
                    </div>
                    <p className="mt-3 text-sm leading-7 text-steel">{item.text}</p>
                  </div>
                </article>
              );
            })}
          </div>
        </section>

        <section id="angles" className="border-y border-ink/10 bg-ink text-paper">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div>
              <p className="text-sm font-bold text-brass">سه زاویه‌ای که دستگاه می‌خواند</p>
              <h2 className="mt-2 text-3xl font-extrabold">تنظیم، با عدد؛ نه با چشم</h2>
              <p className="mt-4 text-sm leading-7 text-paper/75">
                دستگاه به‌روز، زاویه چرخ را قبل و بعد از کار نشان می‌دهد. به همین خاطر سایش لاستیک و
                کشیدن فرمان، شانسی درست نمی‌شود.
              </p>
            </div>
            <ol className="grid gap-4 sm:grid-cols-3">
              {ANGLES.map((item) => (
                <li key={item.name} className="border border-paper/15 p-4">
                  <h3 className="text-lg font-extrabold text-brass">{item.name}</h3>
                  <p className="mt-2 text-sm leading-7 text-paper/80">{item.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="parts" className="scroll-mt-20 mx-auto grid max-w-6xl items-center gap-8 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-2">
          <div className="overflow-hidden border border-ink/10">
            <img
              src="/media/stock.jpg"
              alt="قفسه‌های انبار قطعات جلوبندی و زیربندی"
              className="aspect-[3/2] h-full w-full object-cover"
            />
          </div>
          <div>
            <p className="text-sm font-bold text-brass-deep">مزیت مجموعه</p>
            <h2 className="mt-2 text-3xl font-extrabold leading-tight sm:text-4xl">
              قطعه را خودتان تهیه نکنید
            </h2>
            <p className="mt-4 text-base leading-8 text-steel">
              اگر ایراد از جلوبندی یا زیربندی خودرو باشد، لازم نیست جداگانه دنبال قطعه‌ی یدکی
              بگردید. انبار مجموعه قطعات خودروهای مختلف را موجود دارد تا تعمیر هم سریع‌تر پیش برود،
              هم قطعه با همان کاری که انجام می‌شود جور باشد.
            </p>
            <ul className="mt-6 space-y-3 text-sm leading-7">
              {[
                "معطل خرید قطعه از بازار نمی‌مانید.",
                "قطعه کنار همان کاری انتخاب می‌شود که روی خودرو لازم است.",
                "برای خودروی خاص، موجودی را قبل از مراجعه تلفنی چک کنید.",
              ].map((line) => (
                <li key={line} className="flex gap-3">
                  <Check className="mt-1 size-4 shrink-0 text-brass-deep" aria-hidden="true" />
                  <span>{line}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="method" className="scroll-mt-20 border-t border-ink/10 bg-paper">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
            <h2 className="text-3xl font-extrabold sm:text-4xl">از ورود خودرو تا تحویل</h2>
            <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((step) => (
                <li key={step.n} className="border border-ink/10 p-5">
                  <p className="font-extrabold text-brass-deep">{step.n}</p>
                  <h3 className="mt-3 text-lg font-extrabold">{step.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-steel">{step.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="visit" className="scroll-mt-20 bg-ink text-paper">
          <div className="mx-auto grid max-w-6xl gap-6 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-2">
            <div className="border border-paper/15 p-6 sm:p-8">
              <p className="text-sm font-bold text-brass">مراجعه</p>
              <h2 className="mt-2 text-3xl font-extrabold">اتوسرویس وحید نیکوکار</h2>
              <p className="mt-4 flex gap-3 text-base leading-8 text-paper/85">
                <MapPin className="mt-1 size-5 shrink-0 text-brass" aria-hidden="true" />
                <span>{ADDRESS}</span>
              </p>
              <a href={TEL} className="mt-4 flex items-center gap-3 text-2xl font-extrabold text-brass">
                <Phone className="size-6" aria-hidden="true" />
                <span dir="ltr">{PHONE_FA}</span>
              </a>
              <p className="mt-3 text-sm text-paper/70">نوبت با تماس یا پیام هماهنگ می‌شود.</p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <a
                  href={MAPS}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-12 items-center justify-center rounded-full bg-paper px-5 text-sm font-extrabold text-ink"
                >
                  مسیریابی
                </a>
                <a
                  href={NESHAN}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-12 items-center justify-center rounded-full border border-paper/25 px-5 text-sm font-bold"
                >
                  نقشه نشان
                </a>
                <button
                  type="button"
                  onClick={copyAddress}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-paper/25 px-5 text-sm font-bold"
                >
                  {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
                  {copied ? "کپی شد" : "کپی آدرس"}
                </button>
              </div>
            </div>

            <form onSubmit={sendVisit} className="border border-paper/15 bg-paper p-6 text-ink sm:p-8">
              <h2 className="text-2xl font-extrabold">درخواست نوبت</h2>
              <p className="mt-2 text-sm leading-7 text-steel">
                مشخصات را بنویسید. پیام در واتساپ باز می‌شود تا همان را برای مجموعه بفرستید.
              </p>
              <label className="mt-5 block text-sm font-bold" htmlFor="guest-name">
                نام
              </label>
              <input
                id="guest-name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                autoComplete="name"
                suppressHydrationWarning
                className="mt-2 h-12 w-full border border-ink/15 bg-paper px-3 text-base outline-none focus-visible:border-brass-deep"
              />
              <label className="mt-4 block text-sm font-bold" htmlFor="guest-car">
                مدل خودرو
              </label>
              <input
                id="guest-car"
                value={car}
                onChange={(event) => setCar(event.target.value)}
                placeholder="مثلاً پژو ۴۰۵"
                suppressHydrationWarning
                className="mt-2 h-12 w-full border border-ink/15 bg-paper px-3 text-base outline-none placeholder:text-steel/70 focus-visible:border-brass-deep"
              />
              <label className="mt-4 block text-sm font-bold" htmlFor="guest-note">
                مشکل خودرو
              </label>
              <textarea
                id="guest-note"
                value={note}
                onChange={(event) => setNote(event.target.value)}
                rows={4}
                placeholder="لرزش فرمان، کشیدن به یک سمت، صدای جلوبندی…"
                suppressHydrationWarning
                className="mt-2 w-full border border-ink/15 bg-paper px-3 py-3 text-base leading-7 outline-none placeholder:text-steel/70 focus-visible:border-brass-deep"
              />
              <button
                type="submit"
                className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-ink text-sm font-extrabold text-paper"
              >
                <MessageCircle className="size-4" aria-hidden="true" />
                ارسال در واتساپ
              </button>
            </form>
          </div>
        </section>

        <section id="faq" className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20">
          <h2 className="text-3xl font-extrabold">پرسش‌های رایج</h2>
          <div className="mt-6 border-t border-ink/10">
            {FAQS.map((item, index) => {
              const isOpen = faq === index;
              return (
                <div key={item.q} className="border-b border-ink/10">
                  <button
                    type="button"
                    className="flex w-full items-center justify-between gap-4 py-4 text-start text-base font-extrabold"
                    aria-expanded={isOpen}
                    onClick={() => setFaq(isOpen ? -1 : index)}
                  >
                    {item.q}
                    <span className="text-brass-deep" aria-hidden="true">
                      {isOpen ? "−" : "+"}
                    </span>
                  </button>
                  {isOpen ? <p className="pb-4 text-sm leading-8 text-steel">{item.a}</p> : null}
                </div>
              );
            })}
          </div>
        </section>
      </main>

      <footer className="border-t border-ink/10 pb-24 md:pb-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-steel sm:px-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-extrabold text-ink">اتوسرویس وحید نیکوکار</p>
            <p className="mt-1 max-w-md leading-7">{ADDRESS}</p>
          </div>
          <a href={TEL} className="font-bold text-ink" dir="ltr">
            {PHONE_FA}
          </a>
        </div>
      </footer>

      <div className="fixed inset-x-0 bottom-0 z-40 flex gap-2 border-t border-paper/15 bg-ink p-3 md:hidden">
        <a
          href={TEL}
          className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-paper text-sm font-extrabold text-ink"
        >
          <Phone className="size-4" aria-hidden="true" />
          تماس
        </a>
        <a
          href={WA}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-brass text-sm font-extrabold text-ink"
        >
          <MessageCircle className="size-4" aria-hidden="true" />
          واتساپ
        </a>
      </div>
    </div>
  );
}

function Mark() {
  return (
    <svg viewBox="0 0 40 40" className="size-10 shrink-0" aria-hidden="true">
      <rect width="40" height="40" fill="#12161a" />
      <circle cx="20" cy="20" r="11" fill="none" stroke="#e2b15c" strokeWidth="1.6" />
      <circle cx="20" cy="20" r="3" fill="none" stroke="#e2b15c" strokeWidth="1.6" />
      <path d="M20 6v6M20 28v6M6 20h6M28 20h6" stroke="#f4f0e6" strokeWidth="1.4" />
    </svg>
  );
}
