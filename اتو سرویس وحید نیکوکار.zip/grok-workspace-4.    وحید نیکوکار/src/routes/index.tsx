import { createFileRoute } from "@tanstack/react-router";
import { Site } from "@/components/site";

const TITLE = "اتوسرویس وحید نیکوکار | جلوبندی، زیربندی و تنظیم زاویه چرخ";
const DESCRIPTION =
  "جلوبندی و زیربندی خودرو با دستگاه تنظیم زاویه چرخ، بالانس و رفع لرزش. انبار قطعات کنار کار است؛ لازم نیست قطعه را جدا تهیه کنید. تهران، خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱.";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "AutoRepair",
  name: "اتوسرویس وحید نیکوکار",
  telephone: "+989123434464",
  image: "/media/bay.jpg",
  address: {
    "@type": "PostalAddress",
    streetAddress: "خیابان آزادی، ابتدای خیابان بهبودی، پلاک ۳۸ تا ۴۱",
    addressLocality: "تهران",
    addressCountry: "IR",
  },
  areaServed: "تهران",
  description: DESCRIPTION,
};

export const Route = createFileRoute("/")({
  component: Site,
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(jsonLd),
      },
    ],
  }),
});
